var App = angular.module('sampleApp', ['ngRoute']);
App.run(function($rootScope) {

    $rootScope.Cmpny = {
        CmpName: "IGATE",
        CmpStrength: 500,



    };
    $rootScope.color = [{
        name: 'Abhishek',
        no: 70111111,
        email: 'abhi@gmail.com'
    }, {
        name: 'Akash',
        no: 80223222,
        email: 'akash@gmail.com'
    }, {
        name: 'Ankit',
        no: 6522322,
        email: 'ankit@gmail.com'
    }, {
        name: 'Amit',
        no: 75222221,
        email: 'amit@gmail.com'
    }, {
        name: 'Anish',
        no: 67222211,
        email: 'anish@gmail.com'
    }];
    var user = getCookie("username");
    if (user != "") {
        $rootScope.alluser = JSON.parse(getCookie("username"));
    } else {
        $rootScope.alluser = JSON.parse(checkCookieandget($rootScope.color));
    }

});
App.factory('addfactory', function() {
    var factory = {};

    factory.multiply = function(old, newemp) {

        old.push(newemp);
        setCookie("newuser", old, 3);
        var ab = JSON.parse(checkCookieandget(old));

        return ab;
    }
    return factory;
});

App.service('Addservice', function(addfactory) {
    this.add = function(existing, newemp) {
        return addfactory.multiply(existing, newemp);
    }
});

App.config(function($routeProvider, $locationProvider) {
    $routeProvider

        .when('/', {
        templateUrl: 'Default.html'
    })

    .when('/addEmp', {
        templateUrl: 'Add.html',
        controller: 'validateCtrl'
    })

    .when('/showEmp', {
        templateUrl: 'View.html',
        controller: 'empController'

    }).
    when('/modifyEmp', {
        templateUrl: 'Modify.html',
        controller: 'modController'

    })

    .otherwise({
        redirectTo: '/'
    });



    $locationProvider.html5Mode(false);
    //$locationProvider.hashPrefix('!');
});
App.controller('validateCtrl', function($scope, Addservice) {
    $scope.user = 'John Doe';
    $scope.email = 'john.doe@gmail.com';
    $scope.number = '2345675';
    $scope.square = function() {
        var number = $scope.number;
        var name = $scope.user;
        var email = $scope.email;
        var newEmp = objectconverter(name, number, email);
        $scope.alluser = Addservice.add($scope.alluser, newEmp);
    }
});
App.controller('empController', function($scope) {
    var user = getCookie("username");
    if (user != "") {
        $scope.alluser = JSON.parse(user);
    } else {
        $scope.alluser = JSON.parse(checkCookieandget($rootScope.color));
    }
});
App.controller('modController', function($scope) {
    $scope.addRecipient = function(arg) {
        var a;
        for (var i = 0; i < $scope.alluser.length; i++) {
            if ($scope.alluser[i] === arg) {

                $scope.alluser = JSON.parse(checkCookieandget($scope.alluser));
                break;
            }
        }
    }
});